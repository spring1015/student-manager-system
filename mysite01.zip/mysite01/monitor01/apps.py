from django.apps import AppConfig


class Monitor01Config(AppConfig):
    name = 'monitor01'
