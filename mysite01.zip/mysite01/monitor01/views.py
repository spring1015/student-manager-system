from django.shortcuts import render,redirect

# Create your views here.
from django.shortcuts import HttpResponse

import MySQLdb

def login(request):
    
    return HttpResponse('<h1>调转monitor测试成功</h1>')
    
#查询操作，以后所有的添加、删除、编辑操作完数据库后都可以调整该函数进行查询并显示
def classes(request):
    
    conn = MySQLdb.connect(host='127.0.0.1',port=3306,user='root',passwd='root',database='s4db65',charset='utf8')
    #默认cursor的返回值是元组，使用cursorclass = MySQLdb.cursors.DictCursor可以将返回结果变成字典
    cursor = conn.cursor(cursorclass = MySQLdb.cursors.DictCursor)
    cursor.execute('select id,title from class')
    class_list = cursor.fetchall()
    print(class_list)
    
    # 关闭光标对象
    cursor.close()
    # 关闭数据库连接
    conn.close()
    return render(request,'classes.html',{'class_list':class_list})
    

    
def add_class(request):
    if request.method == 'GET':
        return render(request,'add_class.html')
    else:
        print(request.POST)
        v = request.POST.get('title') #title是前台name为title的标签
        conn = MySQLdb.connect(host='127.0.0.1',port=3306,user='root',passwd='root',database='s4db65',charset='utf8')
        #默认cursor的返回值是元组，使用cursorclass = MySQLdb.cursors.DictCursor可以将返回结果变成字典
        cursor = conn.cursor(cursorclass = MySQLdb.cursors.DictCursor)
        
        cursor.execute('insert into class(title) values(%s)',[v,])
        #提交
        conn.commit()
        
        cursor.close()
        conn.close()
        return redirect('/monitor/classes')



def del_class(request):
    nid = request.GET.get('nid')
    print(nid)
    conn = MySQLdb.connect(host='127.0.0.1',port=3306,user='root',passwd='root',database='s4db65',charset='utf8')
    #默认cursor的返回值是元组，使用cursorclass = MySQLdb.cursors.DictCursor可以将返回结果变成字典
    cursor = conn.cursor(cursorclass = MySQLdb.cursors.DictCursor)
    cursor.execute('delete from class where id =%s',[nid,])
    #删除后同样需要提交
    conn.commit()
    # 关闭光标对象
    cursor.close()
    # 关闭数据库连接
    conn.close()
    #redirect('/monitor/classes')相当于调用另一个函数,且只有客户端（即：浏览器）可以重定向。
    #classes.html页面的删除按钮，浏览器一共向服务器发了两次http请求，一次是del_class请求，另一次是重定向到classes的请求。一次请求一次响应，即：一次请求一种操作
    #重定向是响应头中location中有重定向的地址，发给浏览器，然后浏览器在请求这个地址
    return redirect('/monitor/classes') 


def edit_class(request):
    if request.method == 'GET':
        nid = request.GET.get('nid')
        conn = MySQLdb.connect(host='127.0.0.1',port=3306,user='root',passwd='root',database='s4db65',charset='utf8')
        cursor = conn.cursor(cursorclass = MySQLdb.cursors.DictCursor)
        cursor.execute('select id,title from class where id =%s',[nid,])
        class_list = cursor.fetchone()
        print(class_list)
        cursor.close()
        conn.close()
    
        return render(request,'edit_class.html',{'class_list':class_list})
        
    else:
        nid = request.GET.get('nid')
        title = request.POST.get('title')
        print(title)
        conn = MySQLdb.connect(host='127.0.0.1',port=3306,user='root',passwd='root',database='s4db65',charset='utf8')
        cursor = conn.cursor(cursorclass = MySQLdb.cursors.DictCursor)
        cursor.execute('update class set title=%s where id =%s',[title,nid,])
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect('/monitor/classes')
        

def students(request):
    
    return render(request,'students.html')

