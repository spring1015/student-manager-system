from django.shortcuts import render

from django.shortcuts import HttpResponse

# Create your views here.

#以下为新增
def login(request):

    print(request.method)
    
    if request.method == 'GET':
        
        return render(request,'login.html')
    
    elif request.method == 'POST':
        u = request.POST.get('user')
        print(u)
        p = request.POST.get('pwd')
        print(p)
        dict_list = {1:u,2:p}
        return render(request,'login_info.html',{'dict_list':dict_list})
    
