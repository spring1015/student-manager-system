from django.apps import AppConfig


class Cmb01Config(AppConfig):
    name = 'cmb01'
