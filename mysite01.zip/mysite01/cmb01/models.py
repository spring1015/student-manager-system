from django.db import models

# Create your models here.
class UserInfo(models.Model):
    #id列，自增，主键
    #用户名列，字符串类型，指定长度
    #字符串、数字、时间、二进制
    username = models.CharField(max_length=32)
    password = models.CharField(max_length=60)
    email = models.CharField(max_length=60)
    gender = models.CharField(max_length=60,null=True)
